package com.cg.wps.exception;

public class TransactionException extends Exception {

	public TransactionException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	public TransactionException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
