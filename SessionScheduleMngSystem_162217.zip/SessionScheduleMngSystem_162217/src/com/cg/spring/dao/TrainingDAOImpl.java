package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.spring.model.Training;


@Repository
public class TrainingDAOImpl implements ITrainingDAO{
	@PersistenceContext
	EntityManager manager;

	@Override
	public List<Training> getAll() 
	{
		Query query = manager.createQuery("select cus from Customer cus");
		List<Training> list = query.getResultList();
		return list;
	}

}
