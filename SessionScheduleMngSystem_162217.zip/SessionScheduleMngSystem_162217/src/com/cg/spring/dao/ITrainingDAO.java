package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.model.Training;

public interface ITrainingDAO {
	public List<Training> getAll();

}
