package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.exception.TrainingException;
import com.cg.spring.model.Training;
import com.cg.spring.service.ITrainingService;

@Controller
public class TrainingController {

	@Autowired
	ITrainingService service;
	
	@RequestMapping("/")
	public String showindex() {
		return "index";
	}

	@RequestMapping("/home")
	public String showHome() {
		return "home";
	}

	@RequestMapping(value = "/ScheduledSessions")
	public String processShow(Model model) throws TrainingException {
		String view = "";
		List<Training> list = service.getAll();
		if (list != null) {
			model.addAttribute("listTrn", list);
			view = "ScheduledSessions";

		} else {
			throw new TrainingException("display is not correct");

		}
		return view;

	}

	@RequestMapping("/Success")
	public String showSuccess(Model model)throws TrainingException {
		String view = "";
		List<Training> list = service.getAll();
		if (list != null) {
			model.addAttribute("listTrn", list);
			view = "Success";
		}
		else {
			throw new TrainingException("display is not correct");
		}
		return view;
	}

}
