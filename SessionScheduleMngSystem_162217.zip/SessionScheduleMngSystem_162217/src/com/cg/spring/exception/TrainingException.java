package com.cg.spring.exception;

public class TrainingException extends Exception{
	
	public TrainingException(String message) {
		super(message);
	}
	

}
