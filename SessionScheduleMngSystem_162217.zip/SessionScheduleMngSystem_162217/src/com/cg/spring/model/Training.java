package com.cg.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "scheduledsession")
public class Training {

	@Id
	@Column(length = 5)
	private int Id;
	@Column(length = 10)
	private String name;
	@Column(length = 10)
	private int duration;
	@Column(length = 10)
	private String faculty;
	@Column(length = 10)
	private String mode1;
	
	

	public Training() {
		super();
	}

	public Training(int id, String name, int duration, String faculty, String mode1) {
		super();
		Id = id;
		this.name = name;
		this.duration = duration;
		this.faculty = faculty;
		this.mode1 = mode1;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getMode1() {
		return mode1;
	}

	public void setMode1(String mode1) {
		this.mode1 = mode1;
	}

}
