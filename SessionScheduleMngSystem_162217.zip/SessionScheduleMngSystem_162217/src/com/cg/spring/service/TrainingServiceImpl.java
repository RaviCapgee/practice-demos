package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.dao.ITrainingDAO;
import com.cg.spring.model.Training;
@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService {

	@Autowired
	ITrainingDAO dao;

	@Override
	public List<Training> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}
}
