package com.cg.spring.service;

import java.util.List;

import com.cg.spring.model.Training;


public interface ITrainingService {
	public List<Training> getAll();

}
